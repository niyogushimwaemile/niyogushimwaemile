

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class GetPermissions
 */
@WebServlet("/GetPermissions")
public class GetPermissions extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {


		PrintWriter out = response.getWriter();

		HttpSession session = request.getSession(false);
		String name = (String) session.getAttribute("name");
		String role = (String) session.getAttribute("role");
		String regno = (String) session.getAttribute("regno");

		int userid = Integer.parseInt(session.getAttribute("id").toString());
		
		   if(name == null){
			   response.sendRedirect("index.jsp");
		   }
		   
		   String data = "";
		   int page = Integer.parseInt(request.getParameter("page"));
		   
		   try {
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ops","root","");
			
			Statement statement = con.createStatement(); 
			
			ResultSet rs = statement.executeQuery("SELECT * FROM permissions INNER JOIN students ON permissions.RegNo=students.RegNo WHERE students.RegNo='"+regno+"' LIMIT 5 OFFSET "+page);
			int i=0;
			while(rs.next()){
				
				i+=1;
				data += "<tr>"
						+"<td>"+rs.getString("PermissionID")+"</td>"
						+"<td>"+rs.getString("FirstName")+" "+rs.getString("LastName")+"</td>"
						+"<td>"+rs.getString("RegNo")+"</td>"
						+"<td>"+rs.getString("Department")+"</td>"
						+"<td>"+rs.getString("Reason")+"</td>"
						+"<td>"+rs.getString("LeaveStartDate")+"</td>"
						+"<td>"+rs.getString("LeaveEndDate")+"</td>"
						+"<td>"+rs.getString("Status")+"</td>"
						+"<td>";

				if(rs.getString("Status").equals("Pending")) {
					data += "<a onmouseover=\"document.getElementById('edit1').value='"+rs.getString("LeaveStartDate")+"'; "
							+ "document.getElementById('edit2').value='"+rs.getString("LeaveEndDate")+"';"
							+ "document.getElementById('pid').value='"+rs.getString("PermissionID")+"';"
							+ "document.getElementById('edit3').value='"+rs.getString("Reason")+"'\" "
							+ ""
							+ "type=\"button\" class=\"text-success\" data-toggle=\"modal\" data-target=\"#editPermission\"><i class='fa fa-edit'></i></a>&nbsp;"
							+ ""
							+ "<a onmouseover=\"document.getElementById('del').value="+rs.getString("PermissionID")+"\" href=\"?id="+rs.getString("PermissionID")+"\" type=\"bukktton\" class=\"text-danger\" data-toggle=\"modal\" data-target=\"#deletePermission\">"
									+ "<i class='fas fa-trash-alt'></i></a>";
				}
				
					data+="</td>"
						+"</tr>";
			}
			
			out.print(data);

			rs.close();
			statement.close();
			con.close();
		   }
			catch(Exception e) {
				out.print(e.getMessage());
			}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
