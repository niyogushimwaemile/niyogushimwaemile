

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class CheckLogin
 */
@WebServlet("/CheckLogin")
public class CheckLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		PreparedStatement stm1 = null;
		PreparedStatement stm2 = null;
		PreparedStatement stm3 = null;
		
		String user = null;
		PrintWriter out = response.getWriter();
		try {

			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ops","root","");


			
			stm1 = con.prepareStatement("SELECT * from studentaccounts WHERE Username='"+username+"' AND Password='"+password+"'");
			stm2 = con.prepareStatement("SELECT * from administrators WHERE Username='"+username+"' AND Password='"+password+"'");
			stm3 = con.prepareStatement("SELECT * from superadmins WHERE Username='"+username+"' AND Password='"+password+"'");

			ResultSet count1=stm1.executeQuery();
			ResultSet count2=stm2.executeQuery();
			ResultSet count3=stm3.executeQuery();
			

			
						
			if(count1.next()) {
				//SESSION 
				HttpSession session = request.getSession();
				session.setAttribute("name", count1.getString("Username"));
				session.setAttribute("id", count1.getInt("StudentAccountID"));
				session.setAttribute("regno", count1.getString("RegNo"));
				session.setAttribute("role", "student");
				
			response.sendRedirect("StudentLanding"); //GO TO ANOTHER PAGE 
								
			}
			
			else if(count2.next()) {
				//SESSION 
				HttpSession session = request.getSession();
				session.setAttribute("name", (count2.getString("FirstName")+" "+count2.getString("LastName")));
				session.setAttribute("id", count2.getInt("AdminID"));
				session.setAttribute("role", "dean");
				
			    response.sendRedirect("AdminLanding");  //GO TO ANOTHER PAGE 
				
				
			}

			
			else if(count3.next()) {
				//SESSION 
				HttpSession session = request.getSession();
				session.setAttribute("name", (count3.getString("FirstName")+" "+count3.getString("LastName")));
				session.setAttribute("id", count3.getInt("SuperAdminID"));
				session.setAttribute("role", "super");
				
			response.sendRedirect("SuperLanding"); //GO TO ANOTHER PAGE 
				
			}
			else {
				String div ="<div class=\"alert alert-danger alert-dismissible fade show\" role=\"alert\">\r\n" + 
						"  <strong>Nooo!</strong> Incorrect username or passwords" + 
						"  <button type=\"button\" class=\"btn-close\" data-bs-dismiss=\"alert\" aria-label=\"Close\"></button>\r\n" + 
						"</div>";
				request.setAttribute("error", div);
				RequestDispatcher dispatcher = request.getRequestDispatcher("index.jsp");
				dispatcher.forward(request, response);
			}
						
		
		}
		catch(Exception e) {
			
			String div = "<div class=\"alert alert-danger alert-dismissible fade show\" role=\"alert\">\r\n" + 
					"  <strong>Oops!</strong>" +e.getMessage() + 
					"  <button type=\"button\" class=\"btn-close\" data-bs-dismiss=\"alert\" aria-label=\"Close\"></button>\r\n" + 
					"</div>";
			request.setAttribute("error", div);
			RequestDispatcher dispatcher = request.getRequestDispatcher("index.jsp");
			dispatcher.forward(request, response);
		}
	
	}

}
