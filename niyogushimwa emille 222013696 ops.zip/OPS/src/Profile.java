

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Profile
 */
@WebServlet("/Profile")
public class Profile extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		PrintWriter out = response.getWriter();

		HttpSession session = request.getSession(false);
		String name = (String) session.getAttribute("name");
		String role = (String) session.getAttribute("role");
		String regno = (String) session.getAttribute("regno");

		int userid = Integer.parseInt(session.getAttribute("id").toString());
		   if(name == null || !role.equals("student")){
			   response.sendRedirect("index.jsp");
		   }
		   
		   try {
		
				
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ops","root","");
		
		Statement statement = con.createStatement(); 
		
		ResultSet rs = statement.executeQuery("SELECT * FROM students WHERE RegNo='"+regno+"'");
		
		rs.next();
		
		
		   String data = "<div class=\"\">" + 
					"                <div class=\"modal-dialog cascading-modal modal-avatar modal-sm\">" + 
					
					"                  <div class=\"modal-content\">" + 
					"                    <div class=\"modal-header\">" + 
					
					"				<i class=\"fas fa-user-circle fa-8x text-dark shadow rounded-circle img-responsive mx-auto mt-2\"></i>"+ 
					"                    </div>"+ 
					"                    <div class=\"modal-body text-center\">" + 
					
					"                      <h4 class=\" mb-2 text-center\"><b> "+rs.getString("FirstName")+" "+rs.getString("LastName")+"</b></h4>" + 
					
					"                      <div class=\"ml-0 mr-0\">"
					+ "						<b>Reg Number:</b> "+rs.getString("RegNo")+"<br>"
					+ "						<b>Email:</b> "+rs.getString("Email")+"<br>"
					+ "						<b>Phone number:</b> "+rs.getString("PhoneNumber")+"<br>"
					+ "						<b>Department:</b> "+rs.getString("Department")+
					"                      </div>" + 
					
					"                      <div class=\"text-center mt-4\">" + 
					"                        <button class=\"btn btn-cyan\"data-toggle=\"modal\" data-target=\"#modalLRFormDemo\">Change password" + 
					"                          <i class=\"fas fa-sign-in-alt\"></i>" + 
					"                        </button>"+
					"                      </div>" + 
					"                    </div>" + 
					"                  </div>"+
					"                  </div>"
					+ ""
					+ "<div class=\"modal fade\" id=\"modalLRFormDemo\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModalLabel\"" + 
					"                aria-hidden=\"true\">" + 
					"                <div class=\"modal-dialog\" role=\"document\">" + 
					"                  <div class=\"modal-content\">" + 
					"                    <div class=\"modal-header\">" + 
					"                      <h5 class=\"modal-title\" id=\"exampleModalLabel\">Change password</h5>" + 
					"                      <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\">" + 
					"                        <span aria-hidden=\"true\">&times;</span>" + 
					"                      </button>" + 
					"                    </div>" + 
					"                    <div class=\"modal-body px-4\">"

					+ "<form action=\"\" method='POST'>						"
					+ "<div class=\"md-form ml-0 mr-0\">" + 
					"                        <input type=\"password\" name='current' id=\"form1\" class=\"form-control\" onkeyup='changePassword(this.id)' required>" + 
					"                        <label for=\"form1\" class=\"ml-0\">Enter current password</label>" + 
					"                        <i id='form1Check'></i>"
					+ "						<span id='get' style='display:none'></span>" + 
					"                      </div>"
					+ "						<div class=\"md-form ml-0 mr-0\">" + 
					"                        <input type=\"password\" id=\"form2\" name='new' class=\"form-control\" onkeyup='changePassword(this.id)' required>" + 
					"                        <label for=\"form2\" class=\"ml-0\">New password</label>"
					+ "						 <i id='form2Check'></i>" + 
					"                      </div>"
					+ "						<div class=\"md-form ml-0 mr-0\">" + 
					"                        <input type=\"password\" id=\"form3\" name='confirm' class=\"form-control\" onkeyup='changePassword(this.id)' required>" + 
					"                        <label for=\"form3\" class=\"ml-0\">Confirm new password</label>"
					+ "						 <i id='form3Check'></i>" + 
					"                      </div>"
					+ "" +
					"                    </div>" + 
					"                    <div class=\"modal-footer\">" + 
					"                      <button type=\"button\" class=\"btn btn-secondary\" data-dismiss=\"modal\">Close</button>" + 
					"                      <button type=\"submit\" id='submit' class=\"btn btn-primary\">Save changes</button>" + 
					"                    </div>" + 
					"			</form>" + 
					"                  </div>"+
					"                </div>" + 
					"              </div>";
					
		   	request.setAttribute("data", data);
			request.setAttribute("title", "Profile");

			RequestDispatcher dispatcher = request.getRequestDispatcher("dashboard.jsp");
			dispatcher.forward(request, response);
		   
			  }
			catch(Exception e) {
				out.print(e.getMessage());
			}
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		PrintWriter out = response.getWriter();

		String current = request.getParameter("current");
		String news = request.getParameter("new");
		String confirm = request.getParameter("confirm");
		
		HttpSession session = request.getSession(false);
		String name = (String) session.getAttribute("name");
		String role = (String) session.getAttribute("role");
		String regno = (String) session.getAttribute("regno");

		int userid = Integer.parseInt(session.getAttribute("id").toString());
		
		   if(name == null){
			   response.sendRedirect("index.jsp");
		   }
		   
		try {

			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ops","root","");
			
			Statement statement = con.createStatement(); 
			
			statement.execute("UPDATE studentaccounts SET Password='"+news+"' WHERE RegNo='"+regno+"'");
			
			response.sendRedirect("Profile");
			
			
			
		}
		catch(Exception e) {
			out.print(e.getMessage());		
		}
	}

}
