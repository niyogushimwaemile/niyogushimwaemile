

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDate;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Permissions
 */
@WebServlet("/Permissions")
public class Permissions extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out = response.getWriter();

		HttpSession session = request.getSession(false);
		String name = (String) session.getAttribute("name");
		String role = (String) session.getAttribute("role");
		String regno = (String) session.getAttribute("regno");

		int userid = Integer.parseInt(session.getAttribute("id").toString());
		
		   if(name == null && role== "student"){
			   response.sendRedirect("index.jsp");
		   }
		   try {
		String data = "<div class=\"card\">"
				+ "<div class=\"card-header\">" +
				"<h4 class='text-center d-inline'>Permissions</h4>"
				+ "<button type=\"button\" class=\"btn btn-primary btn-sm d-inline float-right shadow \" data-toggle=\"modal\" data-target=\"#modalLRFormDemo\">"
				+ "New" + 
				" </button>"
				+ "</div>" + 
				"            <div class=\"card-body\">" +
				"              <!-- Table  -->" + 
				"            <div class=\"table-responsive\">" +
				"              <table class=\"table table-hover\">" + 
				"                <!-- Table head -->" + 
				"                <thead class=\"blue-grey lighten-4\">" + 
				"                  <tr>" + 
				"                    <th>#</th>" + 
				"                    <th>Student Name</th>" + 
				"                    <th>RegNo</th>" + 
				"                    <th>Department</th>"
				+ 					"<th>Reason</th>"
				+ 					"<th>Leave Date</th>"
				+ 					"<th>returning Date</th>"
				+ 					"<th>status</th>" + 
				 					"<th>Edit</th>" +
				
				"                  </tr>" + 
				"                </thead>" + 
				"                <!-- Table head -->" + 
				"" + 
				"                <!-- Table body -->" + 
				"                <tbody id='tableBody'>" + 
				"                  <tr>";
				
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ops","root","");
		
		Statement statement = con.createStatement(); 
		
		ResultSet rs = statement.executeQuery("SELECT * FROM permissions INNER JOIN students ON permissions.RegNo=students.RegNo WHERE students.RegNo='"+regno+"' LIMIT 5");
		int i=0;
		while(rs.next()){
			
			i+=1;
			data += "<tr>"
					+"<td>"+rs.getString("PermissionID")+"</td>"
					+"<td>"+rs.getString("FirstName")+" "+rs.getString("LastName")+"</td>"
					+"<td>"+rs.getString("RegNo")+"</td>"
					+"<td>"+rs.getString("Department")+"</td>"
					+"<td>"+rs.getString("Reason")+"</td>"
					+"<td>"+rs.getString("LeaveStartDate")+"</td>"
					+"<td>"+rs.getString("LeaveEndDate")+"</td>"
					+"<td>"+rs.getString("Status")+"</td>"
					+"<td>";
				if(rs.getString("Status").equals("Pending")) {
					data += "<a onmouseover=\"document.getElementById('edit1').value='"+rs.getString("LeaveStartDate")+"'; "
							+ "document.getElementById('edit2').value='"+rs.getString("LeaveEndDate")+"';"
							+ "document.getElementById('pid').value='"+rs.getString("PermissionID")+"';"
							+ "document.getElementById('edit3').value='"+rs.getString("Reason")+"'\" "
							+ ""
							+ "type=\"button\" class=\"text-success\" data-toggle=\"modal\" data-target=\"#editPermission\"><i class='fa fa-edit'></i></a>&nbsp;"
							+ ""
							+ "<a onmouseover=\"document.getElementById('del').value="+rs.getString("PermissionID")+"\" href=\"?id="+rs.getString("PermissionID")+"\" type=\"bukktton\" class=\"text-danger\" data-toggle=\"modal\" data-target=\"#deletePermission\">"
									+ "<i class='fas fa-trash-alt'></i></a>";
				}
				data+="</td>"
							
					
					+"</tr>";
		}
		
				
				
				
				
				data+="    </tbody></table></div>"
						+ "<ul class='pagination'>"
						+"<li class='page-item'>"
						+ "<a class='page-link' href='#' aria-label='Previous' style=\"pointer-events:none; color:#aaa;cursor:default; decoration:none\" id='prev' onclick=\"getPermissions('previous')\">"
						+ "<span aria-hidden='true'>&laquo;</span>"
						+ "</a>"
						+ "</li>";
				
				ResultSet rs1 = statement.executeQuery("SELECT COUNT(*) AS d FROM permissions WHERE RegNo='"+regno+"'");	
				rs1.next();

						
							data+= "<li class='page-item'>"
							+ "<a class='page-link' href='#'style=\"pointer-events:auto\" onclick=\"getPermissions('pages')\" id='link'>"
							+ "<input type='number' min=\"1\" max='2' maxlength=\"2\" size=\"2\" id='input' size='1' style='display:none' onkeyup=\"getPermissions('typing')\"> <span id='btn'> 1</span> of <span id='of'>"+(rs1.getInt("d"))/5+"</span></a>"
							+ "</li>";
						
						data += "<li class='page-item'>"
						+ "<a class='page-link' aria-label='Next' id='next' onclick=\"getPermissions('next')\">"
						+ "<span aria-hidden='true'>&raquo;</span>"
						+ "</a>"
						+ "</li>"
						+ "</ul>"
						+ "</div>" + 
				 
				"</div>"
				+ "<div class=\"modal fade\" id=\"modalLRFormDemo\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModalLabel\"" + 
				"                aria-hidden=\"true\">" + 
				"                <div class=\"modal-dialog\" role=\"document\">" + 
				"                  <div class=\"modal-content\">" + 
				"                    <div class=\"modal-header\">" + 
				"                      <h5 class=\"modal-title\" id=\"exampleModalLabel\">Request a permission</h5>" + 
				"                      <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\">" + 
				"                        <span aria-hidden=\"true\">&times;</span>" + 
				"                      </button>" + 
				"                    </div>" + 
				"                    <div class=\"modal-body px-4\">"

				+ "<form action=\"CreatePermission\" method='POST'>						"
				+ "<div class=\"md-form ml-0 mr-0\">" + 
				"                        <input type=\"date\" name='leave' id=\"form1\" class=\"form-control\" onchange='checkDate(this.id)' required>" + 
				"                        <label for=\"form1\" class=\"ml-0\">Leave date</label>"+
				
				"                        <i id='form1Check'></i>"
				+ "						<span id='get' 	style='display:none' ></span><br>" + 
				"                      </div>"
				+ "						<div class=\"md-form ml-0 mr-0 mb-3\">" + 
				"                        <input type=\"date\" name='return' id=\"form2\" class=\"form-control\" onchange='checkDate(this.id)' required>" + 
				"                        <label for=\"form2\" class=\"ml-0\">Returning date</label>"
				+ "						 <i id='form2Check'></i>" + 
				"                      </div>"
				+ "						<div class=\"md-form ml-0 mr-0\">" + 
				"                        <br><textarea type=\"password\" name='reason' id=\"form3\" class=\"form-control\" required rows=\"4\""
				+ "				 onfocus=\"focusdReason()\"></textarea>" + 
				"                        <label for=\"form3\" id='lbl3' class=\"ml-2 px-2\" style='z-index:1; background:grey; color:white; border-radius:4px;'>Reason</label>"
				+ "						 <i id='form3Check'></i>" + 
				"                      </div>"
				+ "" +
				"                    </div>" + 
				"                    <div class=\"modal-footer\">" + 
				"                      <button type=\"button\" class=\"btn btn-secondary\" data-dismiss=\"modal\">Close</button>" + 
				"                      <button type=\"submit\" id='submit' class=\"btn btn-primary\">Send request</button>" + 
				"                    </div>" + 
				"			</form>" + 
				"                  </div>"+
				"                </div>"+
				"              </div>"
				
				
				
				
+ "<div class=\"modal fade\" id=\"editPermission\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModalLabel\"" + 
"                aria-hidden=\"true\">" + 
"                <div class=\"modal-dialog\" role=\"document\">" + 
"                  <div class=\"modal-content\">" + 
"                    <div class=\"modal-header\">" + 
"                      <h5 class=\"modal-title\" id=\"exampleModalLabel\">Edit permissions</h5>" + 
"                      <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\">" + 
"                        <span aria-hidden=\"true\">&times;</span>" + 
"                      </button>" + 
"                    </div>" + 
"                    <div class=\"modal-body px-4\">"

+ "<form action=\"EditPermission\" method='POST'>						"
+ "<div class=\"md-form ml-0 mr-0\">" + 
"                        <input type=\"date\" name='leave' id=\"edit1\" class=\"form-control\" onchange='editPermission(this.id)' required>" + 
"                        <label for=\"edit1\" class=\"ml-0\">Leave date</label>"+

"                        <i id='form1Check1'></i>"
+ "						<span id='get1' 	style='display:none' ></span><br>" + 
"                      </div>"
+ "						<div class=\"md-form ml-0 mr-0 mb-3\">" + 
"                        <input type=\"date\" name='return' id=\"edit2\" class=\"form-control\" onchange='editPermission(this.id)' required>" + 
"                        <label for=\"edit2\" class=\"ml-0\">Returning date</label>"
+ "						 <i id='form2Check1'></i>" + 
"                      </div>"
+ "						<div class=\"md-form ml-0 mr-0\">" + 
"                        <br><textarea type=\"password\" name='reason' id=\"edit3\" class=\"px-3 form-control\" required rows=\"4\""
+ "				 onfocus=\"focusdReason()\"></textarea>" + 
"                        <label for=\"edit3\" id='lbl3' class=\"ml-2 px-2\" style='z-index:1; background:grey; color:white; border-radius:4px;'>Reason</label>"
+ "						 <i id='form3Check1'></i>" + 
"                      </div>"
+ "" +
"                    </div>" + 
"                    <div class=\"modal-footer\">" + 
"					<input type='hidden' name='pid' id='pid'>"+
"                      <button type=\"button\" class=\"btn btn-danger\" data-dismiss=\"modal\">Close</button>" + 
"                      <button type=\"submit\" id='submit2' class=\"btn btn-primary\">Save changes</button>" + 
"                    </div>" + 
"			</form>" + 
"                  </div>"+
"                </div>"+
"              </div>"



+ "<div class=\"modal fade\" id=\"deletePermission\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModalLabel\"" + 
"                aria-hidden=\"true\">" + 
"                <div class=\"modal-dialog\" role=\"document\">" + 
"                  <div class=\"modal-content\">" + 
"                    <div class=\"modal-header\">" + 
"                      <h5 class=\"modal-title\" id=\"exampleModalLabel\">Delete permission</h5>" + 
"                      <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\">" + 
"                        <span aria-hidden=\"true\">&times;</span>" + 
"                      </button>" + 
"                    </div>" + 
"                    <div class=\"modal-body px-4\">"+
"			Are you sure you want to delete this permission<br> "
+ "	<i class='fas fa-exclamation-triangle text-warning'></i>This operation cannot be undone."+

"                  </div>"+
"				<div class=\"modal-footer\">" + 
						"<input type='hidden' id='del'>"+
"                      <button type=\"button\" class=\"btn btn-danger\" data-dismiss=\"modal\">Close</button>" + 
"                      <button type=\"submit\" id='submit' class=\"btn btn-success\" onclick=\"deletePermission()\">Yes, delete</button>" + 
"                    </div>" + 
"                </div>"+
"              </div>";


		request.setAttribute("data", data);
		request.setAttribute("title", "Permissions");

		RequestDispatcher dispatcher = request.getRequestDispatcher("dashboard.jsp");
		dispatcher.forward(request, response);
		   }
			catch(Exception e) {
				out.print(e.getMessage());
			}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
