

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class About
 */
@WebServlet("/About")
public class About extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out = response.getWriter();
		
		HttpSession session = request.getSession(false);
		String name = (String) session.getAttribute("name");
		String role = (String) session.getAttribute("role");
		String regno = (String) session.getAttribute("regno");

		int userid = Integer.parseInt(session.getAttribute("id").toString());
		
		   if(name == null){
			   response.sendRedirect("index.jsp");
		   }
		   
		   String data = "<div class=\"pt-2 table-responsive\">"
		   		+ "<h4 class='text-center'> About OPS</h4>"
		   		+ "<table border=0 cellpadding='3' class='mt-5' align='center' class='table'>"
		   		+ "<tr>"
		   		+ "<td align='right'><b>App name:</b></td><td> Online Permission System (ops)</td></tr>"
		   		+ "<tr><td align='right'><b>Version:</b></td> <td>1.0.0</td></tr>"
		   		+ "<tr><td align='right'><b>Year:</b></td> <td>2024</td></tr>"
		   		+ "<tr><td align='right'><b>Use case:</b></td> <td>Colleges</td></tr>"
		   		+ "<tr><td align='right'><b>Licence:</b></td> <td>Certified by Meitech licenses</td></tr>"
		   		+ "<tr><td align='right'><b>Owner:</b></td> <td>Meitech Ltd & Techub Inc.</td></tr>"
		   		+ "<tr><td align='right'><b>Developers:</b></td> <td><a href='#'>Meitech Ltd <i class='fas fa-external-link-alt'></i></a> & <a href='#'>Techub Inc <i class='fas fa-external-link-alt'></i></a></td></tr>"
		   		+ "</table>"
		   		+ "</div>";
		   
		   request.setAttribute("data", data);
			request.setAttribute("title", "About");

			RequestDispatcher dispatcher = request.getRequestDispatcher("dashboard.jsp");
			dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
