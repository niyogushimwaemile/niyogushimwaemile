

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class StudentLanding
 */
@WebServlet("/StudentLanding")
public class StudentLanding extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String data ="<div class=\"card mb-4 wow fadeIn\" onload='graph()'>" + 
				
				"        <!--Card content-->" + 
				"        <div class=\"card-body d-sm-flex justify-content-between\">" + 
				
				"          <h4 class=\"mb-2 mb-sm-0 pt-1\">" + 
				"            <a href=\"#\">Home Page</a>" + 
				"            <span>/</span>" + 
				"            <span>Dashboard</span>" + 
				"          </h4>" + 
				"        </div>" + 
				
				"      </div>" + 
				"      <!-- Heading -->" + 
				
				"      <!--Grid row-->" + 
				"      <div class=\"row wow fadeIn\">" + 
				
				"        <!--Grid column-->" + 
				"        <div class=\"col-md-9 mb-4\">" + 
				
				"          <!--Card-->" + 
				"          <div class=\"card\">" + 
				
				"            <!--Card content-->" + 
				"            <div class=\"card-body\">" + 
				
				"              <canvas id=\"myChart\"></canvas>" + 
				
				"            </div>" + 
				
				"          </div>" + 
				"          <!--/.Card-->" + 
				
				"        </div>" +
				" 		<div class=\"col-md-3 mb-4\">" + 
				
				"          " + 
				"          <!--Card-->" + 
				"          <div class=\"card mb-4\">" + 
				
				"            <!--Card content-->" + 
				"            <div class=\"card-body\">" ;
		
		PrintWriter out = response.getWriter();

		HttpSession session = request.getSession(false);
		String name = (String) session.getAttribute("name");
		String role = (String) session.getAttribute("role");
		String regno = (String) session.getAttribute("regno");

		int userid = Integer.parseInt(session.getAttribute("id").toString());
		
		   if(name == null && role== "student"){
			   response.sendRedirect("index.jsp");
		   }
		   	PreparedStatement stm1 = null;
			PreparedStatement stm2 = null;
			PreparedStatement stm3 = null;
			PreparedStatement stm4 = null;
			PreparedStatement stm5 = null;
			PreparedStatement stm6 = null;
			PreparedStatement stm7 = null;
			PreparedStatement stm8 = null;
			
		   try {
			   Class.forName("com.mysql.cj.jdbc.Driver");
				Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ops","root","");
				
				
				stm1 = con.prepareStatement("SELECT COUNT(*) AS pending FROM permissions WHERE Status='Pending' AND RegNo='"+regno+"'");
				stm2 = con.prepareStatement("SELECT COUNT(*) AS approved FROM permissions WHERE Status='Approved' AND RegNo='"+regno+"'");
				stm3 = con.prepareStatement("SELECT COUNT(*) AS rejected FROM permissions WHERE Status='Denied' AND RegNo='"+regno+"'");
				stm4 = con.prepareStatement("SELECT COUNT(*) AS terminate FROM permissions WHERE Status='Terminated' AND RegNo='"+regno+"'");
				stm5 = con.prepareStatement("SELECT COUNT(*) AS perms FROM permissions WHERE RegNo='"+regno+"'");
				
				ResultSet count1=stm1.executeQuery();
				ResultSet count2=stm2.executeQuery();
				ResultSet count3=stm3.executeQuery();
				ResultSet count4=stm4.executeQuery();
				ResultSet count5=stm5.executeQuery();
				
			
		
				
				data += "  <!-- List group links -->" + 
				"              <div class=\"list-group list-group-flush\">" + 
				"                <a href='Permissions' class=\"list-group-item list-group-item-action waves-effect\">Permissions" + 
				"                  <span class=\"badge badge-primary badge-pill pull-right\">";
				
				while(count5.next()){
					data += count5.getInt("perms") ;
				}
				
				data +=" <i class=\"fas fa-check-circle ml-1\"></i>" + 
				"                  </span>" + 
				"                </a>" + 
				"                <a href='Permissions' class=\"list-group-item list-group-item-action waves-effect\">Accepted" + 
				"                  <span class=\"badge badge-success badge-pill pull-right\">";
				while(count2.next()){
					data += count2.getInt("approved") ;
				}
				
				data +="  <i class=\"fas fa-arrow-up ml-1\"></i>" + 
				"                  </span>" + 
				"                </a>" + 
				"                <a class=\"list-group-item list-group-item-action waves-effect\">Denied" + 
				"                  <span class=\"badge badge-danger badge-pill pull-right\">";
				while(count3.next()){
					data += count3.getInt("rejected") ;
				}
				
				data +="  <i class=\"fa fa-arrow-down ml-1\"></i>" + 
				"	</span>" + 
				"                </a>" + 
				"                <a href='Permissions' class=\"list-group-item list-group-item-action waves-effect\">Pending" + 
				"                  <span class=\"badge badge-warning badge-pill pull-right\">";
				
				while(count1.next()){
					data += count1.getInt("pending") ;
				}
				
				data +="  <i class=\"fa fa-hourglass-half ml-1\"></i>" + 
				 "</span>" + 
				"                </a>" + 
				"                <a class=\"list-group-item list-group-item-action waves-effect\">Terminated" + 
				"                  <span class=\"badge badge-secondary badge-pill pull-right\">";
				while(count4.next()){
					data += count4.getString("terminate") ;
				}
				
				data +="  <i class=\"fas fa-ban ml-1\"></i>" + 
				 "</span>" + 
				"                </a>" + 
				"              </div>" + 
				"              <!-- List group links -->" + 
				
				"            </div>" + 
				
				"          </div>" + 
				"          <!--/.Card-->" + 
				
				"        </div>" ;
				
				
				
			data+=	"      </div>" + 
				"      <!--Grid row-->" + 
				
				
				
				"              </div>" + 
				"              <!-- /.First row-->" + 
				
				"            </div>" + 
				
				"          </div>" + 
				"          <!--/.Card-->" + 
				
				"        </div>" + 
				"        <!--Grid column-->" + 
				
				"      </div>" + 
				"      <!--Grid row-->" + 
				
				"    </div>"
				+ "<script>"
				+ "document.addEventListener('DOMContentLoaded', function(){"
				+ "graph();"
				+ "})"
				+ "</script>";

		request.setAttribute("data", data);
		request.setAttribute("title", "Dashboard");

		RequestDispatcher dispatcher = request.getRequestDispatcher("dashboard.jsp");
		dispatcher.forward(request, response);
		   }
			catch(Exception e) {
				out.print(e.getMessage());
			}
			
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
