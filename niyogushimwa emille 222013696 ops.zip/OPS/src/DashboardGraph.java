

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Arrays;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class DashboardGraph
 */
@WebServlet("/DashboardGraph")
public class DashboardGraph extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		
		HttpSession session = request.getSession(false);
		String name = (String) session.getAttribute("name");
		String role = (String) session.getAttribute("role");
		String regno = (String) session.getAttribute("regno");

		int userid = Integer.parseInt(session.getAttribute("id").toString());
		   if(name == null || !role.equals("student")){
			   response.sendRedirect("index.jsp");
		   }		
		   
		PreparedStatement stm1 = null;
		PreparedStatement stm2 = null;
		PreparedStatement stm3 = null;
		PreparedStatement stm4 = null;
		PreparedStatement stm5 = null;
		PreparedStatement stm6 = null;
		PreparedStatement stm7 = null;
		PreparedStatement stm8 = null;
		PreparedStatement stm9 = null;
		PreparedStatement stm10 = null;
		PreparedStatement stm11 = null;
		PreparedStatement stm12 = null;
		String data[] = new String[12];
		String monthDummy = ""; 
		
	try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ops","root","");

		stm1 = con.prepareStatement("SELECT COUNT(*) AS jan FROM permissions WHERE MONTH(LeaveStartDate)=1 AND RegNo='"+regno+"'");
		stm2 = con.prepareStatement("SELECT COUNT(*) AS feb FROM permissions WHERE MONTH(LeaveStartDate)=2 AND RegNo='"+regno+"'");
		stm3 = con.prepareStatement("SELECT COUNT(*) AS mar FROM permissions WHERE MONTH(LeaveStartDate)=3 AND RegNo='"+regno+"'");
		stm4 = con.prepareStatement("SELECT COUNT(*) AS apr FROM permissions WHERE MONTH(LeaveStartDate)=4 AND RegNo='"+regno+"'");
		stm5 = con.prepareStatement("SELECT COUNT(*) AS may FROM permissions WHERE MONTH(LeaveStartDate)=5 AND RegNo='"+regno+"'");
		stm6 = con.prepareStatement("SELECT COUNT(*) AS jun FROM permissions WHERE MONTH(LeaveStartDate)=6 AND RegNo='"+regno+"'");
		stm7 = con.prepareStatement("SELECT COUNT(*) AS jul FROM permissions WHERE MONTH(LeaveStartDate)=7 AND RegNo='"+regno+"'");
		stm8 = con.prepareStatement("SELECT COUNT(*) AS aug FROM permissions WHERE MONTH(LeaveStartDate)=8 AND RegNo='"+regno+"'");
		stm9 = con.prepareStatement("SELECT COUNT(*) AS sept FROM permissions WHERE MONTH(LeaveStartDate)=9 AND RegNo='"+regno+"'");
		stm10 = con.prepareStatement("SELECT COUNT(*) AS oct FROM permissions WHERE MONTH(LeaveStartDate)=10 AND RegNo='"+regno+"'");
		stm11 = con.prepareStatement("SELECT COUNT(*) AS nov FROM permissions WHERE MONTH(LeaveStartDate)=11 AND RegNo='"+regno+"'");
		stm12 = con.prepareStatement("SELECT COUNT(*) AS dece FROM permissions WHERE MONTH(LeaveStartDate)=12 AND RegNo='"+regno+"'");

		ResultSet count1=stm1.executeQuery();
		ResultSet count2=stm2.executeQuery();
		ResultSet count3=stm3.executeQuery();
		ResultSet count4=stm4.executeQuery();
		ResultSet count5=stm5.executeQuery();
		ResultSet count6=stm6.executeQuery();
		ResultSet count7=stm7.executeQuery();
		ResultSet count8=stm8.executeQuery();
		ResultSet count9=stm9.executeQuery();
		ResultSet count10=stm10.executeQuery();
		ResultSet count11=stm11.executeQuery();
		ResultSet count12=stm12.executeQuery();

		while(count1.next()){ data[0] = count1.getString("jan"); }
		while(count2.next()){ data[1] = count2.getString("feb"); }
		while(count3.next()){ data[2] = count3.getString("mar"); }
		while(count4.next()){ data[3] = count4.getString("apr"); }
		while(count5.next()){ data[4] = count5.getString("may"); }
		while(count6.next()){ data[5] = count6.getString("jun"); }
		while(count7.next()){ data[6] = count7.getString("jul"); }
		while(count8.next()){ data[7] = count8.getString("aug"); }
		while(count9.next()){ data[8] = count9.getString("sept"); }
		while(count10.next()){ data[9] = count10.getString("oct"); }
		while(count11.next()){ data[10] = count11.getString("nov"); }
		while(count12.next()){ data[11] = count12.getString("dece"); }
		
		for(int i=0; i<data.length; i++) {
			if(i!=11) {monthDummy += data[i]+",";}
			else {monthDummy += data[i];}
		}
		
		out.print(monthDummy);
		
	}
	catch(Exception e) {
		out.print(e.getMessage());
	}
	}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
